package br.edu.iftm.manytoone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ManytooneApplicationTests {

	@Test
	void contextLoads() {
	}

}
