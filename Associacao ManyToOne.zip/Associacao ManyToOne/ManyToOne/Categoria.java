package ManyToOne;

public class Categoria {
    private Integer id;
    private String nome;

    //contrutores e getters e setters
}
